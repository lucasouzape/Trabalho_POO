package exercicio_02;

import java.util.HashMap;
import java.util.Scanner;

public class Municipio {
    //HashMap da classe "Municipio"
    private static HashMap<Integer, Imovel> listaImoveis = new HashMap<>();


    //Métodos de Acesso --> GETTERS E SETTERS
    public static HashMap<Integer, Imovel> getListaImoveis() {
        return listaImoveis;
    }


    //Métodos Especiais da Classe
    public static void adicionarImovel(int key, Imovel imovel) {
        listaImoveis.put(key, imovel);
    }

    public static void removerImovel(int key) {
        listaImoveis.remove(key);
    }

    public static void calcularImpostoTotal(int key) {
        if ((listaImoveis.get(key).getMesesAtraso() >= 0) && (listaImoveis.get(key).getMesesAtraso() <= 5)) {
            listaImoveis.get(key).setImposto(listaImoveis.get(key).getImposto() * 1.01f);
        }
        else if ((listaImoveis.get(key).getMesesAtraso() >= 6) && (listaImoveis.get(key).getMesesAtraso() <= 8)) {
            listaImoveis.get(key).setImposto(listaImoveis.get(key).getImposto() * 1.023f);
        }
        else if ((listaImoveis.get(key).getMesesAtraso() >= 9) && (listaImoveis.get(key).getMesesAtraso() <= 10)) {
            listaImoveis.get(key).setImposto(listaImoveis.get(key).getImposto() * 1.03f);
        }
        else if ((listaImoveis.get(key).getMesesAtraso() >= 11) && (listaImoveis.get(key).getMesesAtraso() <= 12)) {
            listaImoveis.get(key).setImposto(listaImoveis.get(key).getImposto() * 1.054f);
        }
        else if (listaImoveis.get(key).getMesesAtraso() > 12) {
            listaImoveis.get(key).setImposto(listaImoveis.get(key).getImposto() * 1.1f);
        }
    }

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Scanner entradaString = new Scanner(System.in);


        int menu, mesesAtraso, key, keyBusca, keyRemocao, keyCalculo;
        String proprietario;
        float impostoMensal;
        Imovel objImovel;


        do {
            exibirMenu();
            menu = entrada.nextInt();

            switch (menu) {
                case 1:
                    System.out.println("===> CADASTRO DE IMÓVEL");

                    System.out.println("Digite o nome do proprietário do imovel: ");
                    proprietario = entradaString.nextLine();

                    System.out.println("Digite o valor do imposto mensal: ");
                    impostoMensal = entrada.nextFloat();

                    System.out.println("Digite a quantidade de meses em atraso: ");
                    mesesAtraso = entrada.nextInt();

                    objImovel = new Imovel(proprietario, impostoMensal, mesesAtraso);

                    System.out.println("Digite a KEY do imóvel: ");
                    key = entrada.nextInt();

                    adicionarImovel(key, objImovel);
                    break;

                case 2:
                    System.out.println("===> BUSCA DE DADOS DE IMÓVEL");

                    System.out.println("Digite a KEY do imóvel que você deseja: ");
                    keyBusca = entrada.nextInt();

                    System.out.println("========== IMÓVEL " + keyBusca + "==========");

                    System.out.println("Nome do proprietário: " + listaImoveis.get(keyBusca).getNomeProprietario());
                    System.out.println("Imposto Mensal: " + listaImoveis.get(keyBusca).getImposto());
                    System.out.println("Meses em atraso: " + listaImoveis.get(keyBusca).getMesesAtraso());

                    break;

                case 3:
                    System.out.println("===> REMOÇÃO DE IMÓVEIS DA LISTA");

                    System.out.println("Digite a KEY do imóvel que você deseja remover: ");
                    keyRemocao = entrada.nextInt();

                    removerImovel(keyRemocao);

                    System.out.println("Imóvel removido com sucesso!");

                    break;

                case 4:
                    System.out.println("===> CALCULAR O IMPOSTO DE UM IMÓVEL");

                    System.out.println("Digite a KEY do imóvel que você deseja calcular o imposto total: ");
                    keyCalculo = entrada.nextInt();

                    System.out.println("O imóvel de ID" + keyCalculo + " possui " + listaImoveis.get(keyCalculo).getMesesAtraso() + " meses de imposto atrasado.");

                    calcularImpostoTotal(keyCalculo);

                    System.out.println("Devido a esse atraso, o novo imposto será de " + String.format("R$ %.2f", listaImoveis.get(keyCalculo).getImposto()));



            }


        } while (menu != 5);

    }

    static void exibirMenu() {
        System.out.println("\n========== MENU DE OPÇÕES: ==========");
        System.out.println("1 - ADICIONAR UM IMÓVEL");
        System.out.println("2 - BUSCAR DADOS DE UM IMOVEL");
        System.out.println("3 - REMOVER UM IMOVEL");
        System.out.println("4 - CALCULAR IMPOSTO DE UM IMOVEL");
        System.out.println("5 - SAIR");
        System.out.print("Digite a opção desejada: ");
    }
}
