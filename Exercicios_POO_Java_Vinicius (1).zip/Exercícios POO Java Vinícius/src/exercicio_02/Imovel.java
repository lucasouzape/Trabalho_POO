package exercicio_02;

public class Imovel {
    private String nomeProprietario;
    private float imposto;
    private int mesesAtraso;


    //Método Construtor
    public Imovel(String nomeProprietario, float imposto, int mesesAtraso) {
        this.setNomeProprietario(nomeProprietario);
        this.setImposto(imposto);
        this.setMesesAtraso(mesesAtraso);
    }


    //Métodos de Acesso --> GETTERS E SETTERS
    public String getNomeProprietario() {
        return nomeProprietario;
    }
    public void setNomeProprietario(String nomeProprietario) {
        this.nomeProprietario = nomeProprietario;
    }
    public float getImposto() {
        return imposto;
    }
    public void setImposto(float imposto) {
        this.imposto = imposto;
    }
    public int getMesesAtraso() {
        return mesesAtraso;
    }
    public void setMesesAtraso(int mesesAtraso) {
        this.mesesAtraso = mesesAtraso;
    }



}
